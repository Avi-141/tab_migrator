"""Entry point for python -m weft."""

from weft.cli import main

if __name__ == "__main__":
    main()
