"""TUI module for interactive tab exploration."""
