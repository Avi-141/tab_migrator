"""Export module for tab extraction and graph building."""
